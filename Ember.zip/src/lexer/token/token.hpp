#include <iostream>
#include "tokenType.hpp"

namespace tkn{


class Token
{
private:
    std::string lexeme;
    TokenType type;

    /* data */
public:
    Token(std::string lex){
        lexeme = lex;
        type = DefineTokenType(lexeme);
    };

    ~Token(){};

    TokenType DefineTokenType(std::string t){
        if(t=="word") return WORD;

        // WORDS
        if (t=="byte") return BYTE;
        if (t=="word") return WORD;
        if (t=="dword") return DOUBLE_WORD;
        if (t=="qword") return QUADRIC_WORD;

        // TYPES
        if (t=="und") return UNDEF;
        if (t=="void") return VOID;
        if (t=="int") return INT;
        if (t=="flt") return FLOAT;
        if (t=="dbl") return DOUBLE;
        if (t=="bool") return BOOL;
        if (t=="chr") return CHAR;
        if (t=="str") return STRING;


        // INLINE T/F
        if (t=="true") return TRUE;
        if (t=="false") return FALSE;

        // IF
        if (t=="if") return IF;
        if (t=="el") return ELSE;

        // LOOPS
        if (t=="for") return TRUE;
        if (t=="while") return WHILE;

        // SUS GUYS
        if (t=="brk") return BREAK;
        if (t=="skp") return SKIP;


        // JUMPS
        if (t=="jmp") return JMP;
        if (t=="jc") return JC; //jump with condition
        if (t=="jg") return JG;
        if (t=="jl") return JL;
        if (t=="je") return JE;
        if (t=="jne") return JNE;
        if (t=="jge") return JGE;
        if (t=="jle") return JLE;

        // MATH AND LOGICAL OPERATIONS
        if (t=="+") return PLUS;
        if (t=="*") return STAR;
        if (t=="-") return MINUS;
        if (t=="|") return OR;
        if (t=="&") return AND;
        if (t=="^") return XOR;
        if (t=="||") return DOR;
        if (t=="&&") return DAND;
        if (t=="!") return EXCLAMATION;

        //SPECIAL SYMBOLS
        if(t=="=") return SET;
        if(t==";") return SEMICOLON;
        if(t==":") return COLON;
        if(t==",") return COMMA;
        if(t==".") return POINT;
        if(t=="?") return QUESTION;

        //COMMENTS

        if(isFloat(t)) return CONST_FLOAT;
        if(isInt(t)) return CONST_INT;
        if(isChar(t)) return CONST_CHAR;
        if(isString(t)) return CONST_STRING;
        
        return ID;
    };

    std::string StringifyType(TokenType t){
        if(t==WORD) return "word";

        // WORDS
        if (t==BYTE) return "byte";
        if (t==WORD) return "word";
        if (t==DOUBLE_WORD) return "dword";
        if (t==QUADRIC_WORD) return "qword";

        // TYPES
        if (t==UNDEF) return "und";
        if (t==VOID) return "void";
        if (t==INT) return "int";
        if (t==FLOAT) return "flt";
        if (t==DOUBLE) return "dbl";
        if (t==BOOL) return "bool";
        if (t==CHAR) return "chr";
        if (t==STRING) return "str";


        // INLINE T/F
        if (t==TRUE) return "true";
        if (t==FALSE) return "false";

        // IF
        if (t==IF) return "if";
        if (t==ELSE) return "el";

        // LOOPS
        if (t==FOR) return "for";
        if (t==WHILE) return "while";

        // SUS GUYS
        if (t==BREAK) return "brk";
        if (t==SKIP) return "skp";


        // JUMPS
        if (t==JMP) return "jmp";
        if (t==JC) return "jc"; //jump with condition
        if (t==JG) return "jg";
        if (t==JL) return "jl";
        if (t==JE) return "je";
        if (t==JNE) return "jne";
        if (t==JGE) return "jge";
        if (t==JLE) return "jle";

        // MATH AND LOGICAL OPERATIONS
        if (t==PLUS) return "+";
        if (t==EQUAL) return "==";
        if (t==STAR) return "*";
        if (t==MINUS) return "-";
        if (t==OR) return "|";
        if (t==AND) return "&";
        if (t==XOR) return "^";
        if (t==DOR) return "||";
        if (t==DAND) return "&&";
        if (t==EXCLAMATION) return "!";

        //SPECIAL SYMBOLS
        if(t==SET) return "set";
        if(t==SEMICOLON) return ";";
        if(t==COLON) return ":";
        if(t==COMMA) return ",";
        if(t==POINT) return ".";
        if(t==QUESTION) return "?";

        if(t==CONST_INT) return "CONST_INT";
        if(t==CONST_FLOAT) return "CONST_FLOAT";
        if(t==CONST_CHAR) return "CONST_CHAR";
        if(t==CONST_STRING) return "CONST_STRING";
        
        return "id";
    };

    bool isInt(std::string lex){
        for (size_t i = 0; i < lex.size(); ++i)
            if(lex[i] < '0' || lex[i] > '9') return false;
        return true;
    }

    bool isFloat(std::string lex){
        if(lex.size() < 2) return false;
        bool floatPoint = false;
        for (size_t i = 0; i < lex.size()-1; ++i)
        {
            if(lex[i] == '.'){
                if(floatPoint) return false;
                floatPoint = true;
                //continue;
            }
            else if(lex[i] < '0' || lex[i] > '9') return false;
        }
        if(lex[lex.size()-1] == 'f')std::cout << "\n" << lex << " is float!" << std::endl;
        return (lex[lex.size()-1] == 'f');
    }

    bool isString(std::string lex){
        return (*lex.begin() == '"') && (*lex.end() == '"');
    }

    bool isChar(std::string lex){
        return (*lex.begin() == '\'') && (*lex.end() == '\'') && lex.size() == 3;
    }


//______________________________________________________________________________
// Getters
//______________________________________________________________________________

public:
    TokenType GetType(){
        return type;
    }

public:
    std::string GetLexeme(){
        return lexeme;
    }

//______________________________________________________________________________
// Additional functions
//______________________________________________________________________________

    void AddToLexeme(char chr){
        lexeme += chr;
    }

    std::string GetInfo(){
        std::string ret = "["+StringifyType(type)+"]"+ lexeme + "\t";
        if(type==SEMICOLON) ret += "\n";
        return ret;
    }


};
}
