namespace tkn{


enum TokenType{

    ID,

// WORDS
    BYTE,
    WORD,
    DOUBLE_WORD,
    QUADRIC_WORD,

// TYPES
    //special
    UNDEF,
    VOID,
    //number
    INT, FLOAT, DOUBLE,
    //boolean
    BOOL,
    //text
    CHAR, STRING,

// INLINE CONSTANTS
    //special
    CONST_UNDEF,
    CONST_VOID,
    //number
    CONST_INT, CONST_FLOAT, CONST_DOUBLE,
    //boolean
    TRUE,FALSE,
    //text
    CONST_CHAR, CONST_STRING,


// CONDITION
    IF, ELSE,


// LOOPING
    FOR,
    WHILE,
    FOREACH,


// SUS GUYS
    BREAK,
    SKIP,


// JUMPS
    JMP,
    JC, //jump with condition
    JG,
    JL,
    JE,
    JNE,
    JGE,
    JLE,



// MATH AND LOGICAL OPERATIONS
    PLUS, // +
    STAR, // *
    MINUS, // -

    OR, // |
    AND, // &
    XOR, // ^

    DOR, // ||
    DAND, // &&

    EXCLAMATION, // !

//COMPARE
    LESS, // <
    GREATER, // >
    LESS_EQUAL, // <=
    GREATER_EQUAL, // >=


    // equal operators
    EQUAL, // ==
    NOT_EQUAL, // !=


// BRACKETS
    LBRA, // {
    RBRA, // }
    LPAR, // (
    RPAR, // )
    LSQR, // [
    RSQR, // ]

// FUNC
    FUNCTION,
    RETURN,

// symbols
    SEMICOLON, // ;
    COLON, // :
    COMMA, // ,
    POINT, // .
    QUESTION, // ?
    AMPERSAND, // &
    SET, // =

// COMMENTS
    LINE_COMMENT, // //
    BLOCK_COMMENT_START, // /*
    BLOCK_COMMENT_END, // */

// MEMALLOC
    NEW,
    DELETE,

    ACCESS_OPERATOR, // ::
};
}
